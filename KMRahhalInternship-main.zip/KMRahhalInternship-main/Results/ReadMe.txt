Directory containing results (results do not need to be on git)
