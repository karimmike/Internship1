# TODOs
List of possible extensions of the project

* Include interaction terms in regressions (e.g., treatment x type of bud...)
* Combine regression for missing predictors and mixed models by applying mixed effects on the residuals?
* Better formalization of chaining time, variables, with respect to expected chain of causality.
* Make some formal description of SMA in the report.